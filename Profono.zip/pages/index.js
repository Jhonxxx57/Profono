
export default function Home() {
  return <h1>ProFono: Sistema Iniciado com Sucesso!</h1>;
}
